#!/usr/bin/env python3

import socket, json, threading, sys
try:
    import serial, serial.tools.list_ports
except ImportError:
    print("Dependency not found: please run 'pip3 install pyserial'")
    exit(1)

ce_id = (0x0451, 0xe008)
max_packet_size = 1024

def sock_recv(s, ser_out):
	global connected
	while connected:
		try:
			data = s.recv(max_packet_size)
			if data:
				if debug_mode:
					print("S->C: Type {:>3}, size {}".format(data[0], len(data)))
				status1 = ser_out.write(len(data).to_bytes(3, byteorder='little'))
				status2 = ser_out.write(data)
				if debug_mode:
					print("S->C completed: ", (status1, status2))
			else:
				connected = False

		except socket.error as e:
			sys.stderr.write('Error: {}\n'.format(e))
	s.close()
	print("Disconnected.")

def connect(server):
	global s, connected
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		s.connect((server, tcp_port))
		
		print("Connected to", server)
		connected = True
		sock_thread = threading.Thread(target=sock_recv, args=(s, ser_out), daemon=True)
		sock_thread.start()
	except Exception as e:
		sys.stderr.write('Error: {}\n'.format(e))

def ser_recv(ser_in, ser_out):
	global s, connected
	print("Serial listening.")
	while True:
		size = int.from_bytes(ser_in.read(3), 'little')
		if size > max_packet_size:
			sys.stderr.write('Error: Got {} bytes from client, but the max packet size is {}\n'.format(size, max_packet_size))
			# todo: we should stop something, as this will 100% cause a desync
		else:
			data = ser_in.read(size)
			packet_type = data[0]
			if debug_mode:
				print("C->S: Type {:>3}, size {}".format(packet_type, size))
			if packet_type == 0:
				# Connect
				if debug_mode: print("Got connect packet")
				server = str(data[1:-1], 'utf-8')
				connect(server)
				if connected:
					ser_out.write(b'\x01\x00\x00\x00')
					if debug_mode: print("B->C: Type   0, size 1")
				else:
					ser_out.write(b'\x01\x00\x00\xF0')
					if debug_mode: print("B->C: Type 253, size 1")
			elif packet_type == 1:
				# Disconnect
				if debug_mode: print("Got disconnect packet")
				connected = False
				s.shutdown(socket.SHUT_RDWR)
				ser_out.write(b'\x01\x00\x00\x01')
				if debug_mode: print("B->C: Type   1, size 1")
			else:
				# Not for us
				if connected:
					status = s.send(data)
					if debug_mode:
						print("C->S completed: ", status)
				else:
					sys.stderr.write('Error: Tried to send a packet without being connected to a server\n')

f = open("config.json","r")
config = json.load(f)
f.close()

tcp_port = config["port"]

pipe_mode = False
if "mode" in config:
	if config["mode"] == "pipe":
		pipe_mode = True
	elif config["mode"] == "CEmu":
		pipe_mode = True
	elif config["mode"] == "cemu":
		pipe_mode = True
	elif config["mode"] == "serial":
		pipe_mode = False
	else:
		print("Invalid mode: " + config["mode"])
		exit(1)
serial_mode = not pipe_mode

debug_mode = False
if "debug" in config:
	debug_mode = config["debug"]

if debug_mode:
	print("Running in debug mode.")

if serial_mode:
	if "serial" in config:
		serial_name = config["serial"]
	else:
		ports = [x for x in serial.tools.list_ports.comports() if (x.vid, x.pid) == ce_id]
		if len(ports) == 0:
			print("No device detected.")
			exit(1)

		serial_name = ports[0].device

		if len(ports) > 1:
			print("Multiple devices detected - using {}".format(serial_name))

	ser = serial.Serial(serial_name, timeout=None)
	ser_in = ser
	ser_out = ser

if pipe_mode:
	oname = config["pipe_out"]
	iname = config["pipe_in"]
	if debug_mode:
		print("Out pipe: " + oname)
		print("In pipe: " + iname)
	ser_out = open(oname, "wb", buffering=0)
	ser_in = open(iname, "rb")
	if debug_mode:
		print("Pipes opened")

print("^C to exit.")

connected = False

try:
	ser_recv(ser_in, ser_out)
except KeyboardInterrupt:
	pass

if serial_mode:
	ser.close()
if pipe_mode:
	ser_in.close()
	ser_out.close()
s.close()
